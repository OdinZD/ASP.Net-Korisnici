﻿using System;
using System.Collections.Generic;
using System.Text;
using VjezbaKorisnici.DAL.Data;

namespace VjezbaKorisnici.BLL.Translators
{
    public class KorisniciTranslator
    {
        public static Korisnici Translate(Korisnici item)
        {
            if (item == null)
            {
                return null;
            }
            var model = new Korisnici
            {
                KorisnikId = item.KorisnikId,
                KorisnickoIme = item.KorisnickoIme,
                Ime = item.Ime,
                Prezime = item.Prezime,
            };
            return model;
        }

        public static List<Korisnici> TranslateList(List<Korisnici> kolekcija)
        {
            if (kolekcija == null)
            {
                return null;
            }
            List<Korisnici> resultData = new List<Korisnici>();
            foreach (var item in kolekcija)
            {
                resultData.Add(Translate(item));
            }
            return resultData;
        }



    }
}
