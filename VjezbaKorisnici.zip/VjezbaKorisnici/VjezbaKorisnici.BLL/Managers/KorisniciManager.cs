﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VjezbaKorisnici.BLL.Services;
using VjezbaKorisnici.BLL.Translators;
using VjezbaKorisnici.DAL.Data;
using VjezbaKorisnici.DAL.Queries;

namespace VjezbaKorisnici.BLL.Managers
{
    public class KorisniciManager : IKorisniciManager
    {
        private readonly VjezbaKorisnici_DEVContext db;

        public KorisniciManager (VjezbaKorisnici_DEVContext ctx)
        {
            db = ctx;
        }

       
        public async Task<Korisnici> DohvatiKorisnika(int id)
        {
            try
            {
                Korisnici data = await KorisnikQueries.DohvatiKorisnika(db, id);
                Korisnici korisniciViewModel = KorisniciTranslator.Translate(data);

                return korisniciViewModel;
            }
            catch (Exception ex)
            {

                throw new Exception("Dogodila se greška prilikom dohvata korisnika putem id-a.", ex);
            }
        }

        public async Task<List<Korisnici>> DohvatiKorisnike(int korisnikId)
        {
            try
            {
                List<Korisnici> data = await KorisnikQueries.DohvatiKorisnike(db, korisnikId);
                return KorisniciTranslator.TranslateList(data);
            }
            catch (Exception e)
            {

                throw new Exception("Dogodila se pogreška prilikom dohvata svih korisnika.", e);
            }
        }


      
    }
}
