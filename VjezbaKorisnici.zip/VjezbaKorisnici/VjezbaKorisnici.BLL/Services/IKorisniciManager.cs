﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VjezbaKorisnici.DAL.Data;

namespace VjezbaKorisnici.BLL.Services
{
    public interface IKorisniciManager
    {
        Task<Korisnici> DohvatiKorisnika(int id);
        
        Task<List<Korisnici>> DohvatiKorisnike(int korisnikId);
    }
}
