using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using VjezbaKorisnici.BLL.Managers;
using VjezbaKorisnici.BLL.Services;


namespace VjezbaKorisnici.Areas.Korisnici.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IKorisniciManager _logger;

        public IndexModel(IKorisniciManager logger)
        {
            _logger = logger;
        }
        [BindProperty(SupportsGet = true)]
        public List<KorisniciManager> Korisnici { get; set; }

        public void OnGet()
        {


        }
    }
}

