﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using VjezbaKorisnici.DAL.Data;

namespace VjezbaKorisnici.DAL.Queries
{
    public class KorisnikQueries
    {

        public static async Task<Korisnici> DohvatiKorisnika(VjezbaKorisnici_DEVContext db, int id)
        {
            try
            {
                return await db.Korisnici
                    .Include(p => p.KorisnickoIme)
                    .Include(p => p.Ime)
                    .Include(p => p.Prezime)
                    .SingleAsync(x => x.KorisnikId == id);
            }
            catch (Exception ex)
            {

                throw new Exception("Dogodila se pogreška prilikom dohvata korisnika", ex);
            }
        }

        public static async Task<List<Korisnici>> DohvatiKorisnike(VjezbaKorisnici_DEVContext db, int korisnikId)
        {
            try
            {
                return await db.Korisnici
                    .Include(p => p.KorisnickoIme)
                    .Include(p => p.Ime)
                    .Include(p => p.Prezime)
                    .Where(x => x.KorisnikId == korisnikId)
                    .ToListAsync();
            }
            catch (Exception ex)
            {

                throw new Exception("Dogodila se pogreška prilikom dohvata svih korisnika", ex);
            }
        }
    }
}
