﻿using System;
using System.Collections.Generic;

namespace VjezbaKorisnici.DAL.Data
{
    public partial class Role
    {
        public Role()
        {
            KorisniciRole = new HashSet<KorisniciRole>();
        }

        public int RolaId { get; set; }
        public string NazivRole { get; set; }

        public virtual ICollection<KorisniciRole> KorisniciRole { get; set; }
    }
}
