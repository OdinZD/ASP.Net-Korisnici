﻿using System;
using System.Collections.Generic;

namespace VjezbaKorisnici.DAL.Data
{
    public partial class KorisniciRole
    {
        public int KorisniciRoleId { get; set; }
        public int KorisnikId { get; set; }
        public int RolaId { get; set; }

        public virtual Korisnici Korisnik { get; set; }
        public virtual Role Rola { get; set; }
    }
}
