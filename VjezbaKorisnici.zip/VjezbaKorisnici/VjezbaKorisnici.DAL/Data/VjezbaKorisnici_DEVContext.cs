﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace VjezbaKorisnici.DAL.Data
{
    public partial class VjezbaKorisnici_DEVContext : DbContext
    {
        public VjezbaKorisnici_DEVContext()
        {

        }

        public VjezbaKorisnici_DEVContext(DbContextOptions<VjezbaKorisnici_DEVContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Dokumenti> Dokumenti { get; set; }
        public virtual DbSet<Korisnici> Korisnici { get; set; }
        public virtual DbSet<KorisniciRole> KorisniciRole { get; set; }
        public virtual DbSet<Role> Role { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DT-ODINP\\SQLEXPRESS;Database=TestKorisnici;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Dokumenti>(entity =>
            {
                entity.HasKey(e => e.DokumentId);

                entity.Property(e => e.DokumentId).HasColumnName("DokumentID");

                entity.Property(e => e.KorisnikId).HasColumnName("KorisnikID");

                entity.Property(e => e.Naziv)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Korisnik)
                    .WithMany(p => p.Dokumenti)
                    .HasForeignKey(d => d.KorisnikId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Dokumenti_Korisnici");
            });

            modelBuilder.Entity<Korisnici>(entity =>
            {
                entity.HasKey(e => e.KorisnikId);

                entity.Property(e => e.KorisnikId).HasColumnName("KorisnikID");

                entity.Property(e => e.Ime).HasMaxLength(200);

                entity.Property(e => e.KorisnickoIme)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Prezime).HasMaxLength(200);
            });

            modelBuilder.Entity<KorisniciRole>(entity =>
            {
                entity.Property(e => e.KorisniciRoleId)
                    .HasColumnName("KorisniciRoleID")
                    .ValueGeneratedNever();

                entity.Property(e => e.KorisnikId).HasColumnName("KorisnikID");

                entity.Property(e => e.RolaId).HasColumnName("RolaID");

                entity.HasOne(d => d.Korisnik)
                    .WithMany(p => p.KorisniciRole)
                    .HasForeignKey(d => d.KorisnikId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KorisniciRole_Korisnici");

                entity.HasOne(d => d.Rola)
                    .WithMany(p => p.KorisniciRole)
                    .HasForeignKey(d => d.RolaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KorisniciRole_Role");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.RolaId);

                entity.Property(e => e.RolaId).HasColumnName("RolaID");

                entity.Property(e => e.NazivRole)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
