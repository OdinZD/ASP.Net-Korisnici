﻿using System;
using System.Collections.Generic;

namespace VjezbaKorisnici.DAL.Data
{
    public partial class Korisnici
    {
        public Korisnici()
        {
            Dokumenti = new HashSet<Dokumenti>();
            KorisniciRole = new HashSet<KorisniciRole>();
        }

        public int KorisnikId { get; set; }
        public string KorisnickoIme { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }

        public virtual ICollection<Dokumenti> Dokumenti { get; set; }
        public virtual ICollection<KorisniciRole> KorisniciRole { get; set; }
    }
}
