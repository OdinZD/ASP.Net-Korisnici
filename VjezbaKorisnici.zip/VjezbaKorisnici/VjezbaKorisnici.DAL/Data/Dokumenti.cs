﻿using System;
using System.Collections.Generic;

namespace VjezbaKorisnici.DAL.Data
{
    public partial class Dokumenti
    {
        public int DokumentId { get; set; }
        public string Naziv { get; set; }
        public int KorisnikId { get; set; }

        public virtual Korisnici Korisnik { get; set; }
    }
}
